#!/bin/bash
set -x

start_x()
{
	local gpu_index=$1
	local display=:${gpu_index}
	Xorg ${display} -config $2/xorg.${gpu_index}.conf -nolisten tcp -sharevts vt${gpu_index} &
}



NUM_SERVICE=`ls $1/xorg.*.conf | wc -l`

for (( i = 0; i < ${NUM_SERVICE}; i++ ))
do
	start_x $i $1
done
