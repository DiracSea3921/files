#!/bin/bash

ps ax | grep qemu-system-x86_64 | grep -v grep | awk '{print $1}' | while read row; do kill $row; done
