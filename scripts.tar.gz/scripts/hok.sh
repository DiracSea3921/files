#!/bin/bash

adb -s 10.100.254.36:5555 shell am start -n com.tencent.tmgp.sgame.MainActivity
adb -s 10.100.254.36:5555 shell am force-stop com.tencent.tmgp.sgame
