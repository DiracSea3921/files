#!/usr/bin/env python3

import re
import subprocess
import getopt
import sys

template = '''Section "ServerFlags"
    Option "DontVTSwitch" "on"
    Option "AutoAddDevices" "off"
    Option "AutoEnableDevices" "off"
    Option "AutoAddGPU" "off"
    Option "AutoBindGPU" "off"
EndSection

Section "Device"
       Identifier "card0"
       Driver "nvidia"
       # lspci output in HEX form of [domain:]bus:device.function
       # BusID in Decimal form of PCI:bus@domain:device:function
       #
       # Example1: lspci (hex): 000a:11:00.0 VGA compatible controller [0300]: bla. bla.
       #           BusID (dec): PCI:17@10:00:00"
       # Example2: lspci (hex): 03:00.0 VGA compatible controller [0300]: bla. bla.
       #           BusID (dec): PCI:03@00:00:00"
       BusID "PCI:$BUSID$"

EndSection

Section "Monitor"
        Identifier "monitor0"
        Option "enable" "true"
EndSection

Section "Screen"
        Identifier "screen0"
        Device "card0"
        Monitor "monitor0"
        DefaultDepth 24
        Option         "AllowEmptyInitialConfiguration" "True"
        SubSection "Display"
                Depth 24
        EndSubSection
EndSection
'''

output_dir = ""

try:
    opts, args = getopt.getopt(sys.argv[1:],"hd:",["help", "output_dir="])
except getopt.GetoptError:
    print("{0} -d <output dir>".format(sys.argv[0]))
    sys.exit(2)

for opt, arg in opts:
    if opt in ("-h", "--help"):
        print("{0} -d <output dir>".format(sys.argv[0]))
        sys.exit()
    elif opt in ("-d", "--output_dir"):
        output_dir = arg;

index = 0
process = subprocess.run(["lspci"], stdout=subprocess.PIPE)
lspci_output = process.stdout.decode("utf-8")
for line in lspci_output.split("\n"):
    if re.match(r".*(3D|VGA).*NVIDIA.*", line):
        bdf = line.split()[0]
        bus, dev, function = re.split(r"[:.]", bdf)
        xorg_bdf = "{0:d}:{1:d}:{2:d}".format(int(bus, 16), int(dev, 16), int(function, 16))
        with open("{0}xorg.{1}.conf".format(output_dir, index), "w") as conf:
            conf.write(template.replace("$BUSID$", xorg_bdf))
        index += 1;
