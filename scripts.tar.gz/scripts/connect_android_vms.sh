#!/bin/bash

for i in $(seq 24)                            
do
	let "port = 5553 + 2 * i"
	echo "adb connect 10.100.254.36:$port"
	adb connect 10.100.254.36:$port
	let "scrport = 1234 + i"
	echo "scrcpy -s 10.100.254.36:$port -p $scrport &"
	scrcpy -s 10.100.254.36:$port -p $scrport &
	sleep 1
done
