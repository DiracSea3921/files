#!/bin/bash

NUM_VMS=$1
VMS_DIR=$2

#NUM_GPU=`lspci | grep VGA | grep NVIDIA | wc -l`
NUM_GPU=1

gpu_index=0

for i in $(seq ${NUM_VMS})
do
	pushd ${VMS_DIR}/android_$i/
	export DISPLAY=:$gpu_index
	echo "DISPLAY = $DISPLAY"
	./start_android &
	let "gpu_index = (gpu_index + 1) % NUM_GPU"
	popd
done
